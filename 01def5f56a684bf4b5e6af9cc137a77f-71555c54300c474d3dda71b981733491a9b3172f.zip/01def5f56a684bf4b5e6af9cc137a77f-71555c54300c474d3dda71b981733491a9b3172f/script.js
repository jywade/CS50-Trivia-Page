function toggleFreeResponse() {
  const freeResponseSection = document.getElementById("free-response-section");
  const toggleButton = document.getElementById("toggle-button");

  if (freeResponseSection.style.display === "none") {
    freeResponseSection.style.display = "block";
    toggleButton.textContent = "Hide Free Response";
  } else {
    freeResponseSection.style.display = "none";
    toggleButton.textContent = "Show Free Response";
  }
}

const toggleButton = document.getElementById("toggle-button");
toggleButton.addEventListener("click", toggleFreeResponse);
